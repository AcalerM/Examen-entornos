// JavaScript source code
const axios = require('axios');

const API_URL = 'https://jsonplaceholder.typicode.com/posts';

async function fetchPosts() {
    try {
        const response = await axios.get(API_URL);
        console.log('Data from API:', response.data);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

fetchPosts();
